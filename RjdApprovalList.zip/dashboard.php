<?php
require('db.php');
include("header.php");
?>

<div class="form">
    <p>Dashboard</p>
    <p>This is for Dashboard.</p>
</div>
<script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>